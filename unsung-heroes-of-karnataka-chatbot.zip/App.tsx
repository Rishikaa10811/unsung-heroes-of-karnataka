import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Message, Role } from './types';
import { sendMessageStream, translateText, getRelatedHeroes } from './services/geminiService';
import ChatHistory from './components/ChatHistory';
import ChatInput from './components/ChatInput';
import Header from './components/Header';
import ErrorDisplay from './components/ErrorDisplay';
import SuggestionBar from './components/SuggestionBar';
import Frontsheet from './components/Frontsheet';

const App: React.FC = () => {
  const [showChat, setShowChat] = useState<boolean>(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      role: Role.MODEL,
      content: "Hello! I am a chatbot dedicated to the unsung heroes of Karnataka. Who would you like to learn about today?",
      showKannada: false,
    },
  ]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!showChat) return;
    
    const translateInitialMessage = async () => {
        const firstMessage = messages[0];
        if (firstMessage && firstMessage.role === Role.MODEL && !firstMessage.kannadaContent && !firstMessage.isTranslating) {
            setMessages(prev => {
                const updated = [...prev];
                updated[0] = {...updated[0], isTranslating: true};
                return updated;
            });
            try {
                const translation = await translateText(firstMessage.content, 'Kannada');
                setMessages(prev => {
                    const updated = [...prev];
                    updated[0] = {...updated[0], kannadaContent: translation.trim(), isTranslating: false};
                    return updated;
                });
            } catch (e) {
                console.error("Failed to translate initial message", e);
                setMessages(prev => {
                    const updated = [...prev];
                    updated[0] = {...updated[0], isTranslating: false};
                    return updated;
                });
            }
        }
    };
    translateInitialMessage();
  }, [showChat]);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSendMessage = useCallback(async (userInput: string) => {
    if (!userInput.trim()) return;

    setError(null);
    setIsLoading(true);
    const userMessage: Message = { role: Role.USER, content: userInput };
    setMessages(prev => [...prev, userMessage, { role: Role.MODEL, content: "", showKannada: false }]);

    try {
      const stream = await sendMessageStream(userInput);
      let fullResponse = "";
      for await (const chunk of stream) {
        fullResponse += chunk.text;
        setMessages(prev => {
          const newMessages = [...prev];
          const lastMessage = newMessages[newMessages.length - 1];
          if (lastMessage && lastMessage.role === Role.MODEL) {
            lastMessage.content = fullResponse;
          }
          return newMessages;
        });
      }

      setMessages(prev => {
        const newMessages = [...prev];
        const lastMessage = newMessages[newMessages.length - 1];
        if (lastMessage && lastMessage.role === Role.MODEL) {
          lastMessage.isTranslating = true;
        }
        return newMessages;
      });

      const kannadaTranslation = await translateText(fullResponse, 'Kannada');
      setMessages(prev => {
        const newMessages = [...prev];
        const lastMessage = newMessages[newMessages.length - 1];
        if (lastMessage && lastMessage.role === Role.MODEL) {
          lastMessage.kannadaContent = kannadaTranslation.trim();
          lastMessage.isTranslating = false;
        }
        return newMessages;
      });

      if (fullResponse.trim()) {
        const relatedHeroes = await getRelatedHeroes(userInput);
        if (relatedHeroes.length > 0) {
            setMessages(prev => {
                const newMessages = [...prev];
                const lastMessage = newMessages[newMessages.length - 1];
                if (lastMessage && lastMessage.role === Role.MODEL) {
                    lastMessage.suggestions = relatedHeroes;
                }
                return newMessages;
            });
        }
      }

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "An unknown error occurred.";
      console.error("Gemini API error:", err);
      setError(`Sorry, I encountered an error. Please try again. Details: ${errorMessage}`);
      setMessages(prev => prev.filter(m => m.role !== Role.MODEL || m.content !== ""));
    } finally {
      setIsLoading(false);
    }
  }, []);

  const handleSuggestionClick = useCallback((suggestion: string, messageIndex: number) => {
    setMessages(prev => {
        const newMessages = [...prev];
        if (newMessages[messageIndex]) {
            const updatedMessage = { ...newMessages[messageIndex] };
            delete updatedMessage.suggestions;
            newMessages[messageIndex] = updatedMessage;
        }
        return newMessages;
    });
    handleSendMessage(suggestion);
  }, [handleSendMessage]);

  const handleToggleTranslation = useCallback((messageIndex: number) => {
    setMessages(prev => {
      const newMessages = [...prev];
      const message = newMessages[messageIndex];
      if (message && message.role === Role.MODEL) {
        message.showKannada = !message.showKannada;
      }
      return newMessages;
    });
  }, []);

  if (!showChat) {
    return <Frontsheet onEnter={() => setShowChat(true)} />;
  }

  return (
    <div className="flex flex-col h-screen text-gray-800 font-sans">
      <Header />
      <main ref={chatContainerRef} className="flex-1 overflow-y-auto p-4 md:p-6">
        <div className="max-w-4xl mx-auto">
          <ChatHistory 
            messages={messages} 
            isLoading={isLoading} 
            onSuggestionClick={handleSuggestionClick} 
            onToggleTranslation={handleToggleTranslation}
          />
          {error && <ErrorDisplay message={error} />}
        </div>
      </main>
      <footer className="bg-white/30 backdrop-blur-sm border-t border-white/50">
        <div className="max-w-4xl mx-auto p-4 md:p-6">
          <SuggestionBar onSuggestionClick={handleSendMessage} isLoading={isLoading} />
          <ChatInput onSendMessage={handleSendMessage} isLoading={isLoading} />
        </div>
      </footer>
    </div>
  );
};

export default App;