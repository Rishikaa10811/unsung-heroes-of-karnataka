import React from 'react';
import { Message } from '../types';
import ChatMessage from './ChatMessage';

interface ChatHistoryProps {
  messages: Message[];
  isLoading: boolean;
  onSuggestionClick: (suggestion: string, messageIndex: number) => void;
  onToggleTranslation: (messageIndex: number) => void;
}

const ChatHistory: React.FC<ChatHistoryProps> = ({ messages, isLoading, onSuggestionClick, onToggleTranslation }) => {
  return (
    <div className="space-y-6">
      {messages.map((msg, index) => (
        <ChatMessage 
          key={index} 
          message={msg} 
          index={index}
          onSuggestionClick={onSuggestionClick}
          onToggleTranslation={onToggleTranslation}
        />
      ))}
      {isLoading && messages.length > 0 && messages[messages.length - 1].content === "" && (
         <div className="flex items-center space-x-2 animate-pulse">
            <div className="h-4 bg-yellow-600/50 rounded w-1/4"></div>
         </div>
      )}
    </div>
  );
};

export default ChatHistory;