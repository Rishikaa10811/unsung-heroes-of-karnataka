import React from 'react';
import { Message, Role } from '../types';
import UserIcon from './icons/UserIcon';
import BotIcon from './icons/BotIcon';
import TranslateIcon from './icons/TranslateIcon';

interface ChatMessageProps {
  message: Message;
  index: number;
  onSuggestionClick: (suggestion: string, messageIndex: number) => void;
  onToggleTranslation: (messageIndex: number) => void;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message, index, onSuggestionClick, onToggleTranslation }) => {
  const isUser = message.role === Role.USER;

  const displayContent = (message.showKannada && message.kannadaContent) ? message.kannadaContent : message.content;

  const formatContent = (content: string) => {
    let formattedContent = content
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>');

    formattedContent = formattedContent.replace(/^- (.*$)/gm, '<li class="ml-4">$1</li>');
    if (formattedContent.includes('<li>') && !formattedContent.includes('<ul>') && !formattedContent.includes('<ol>')) {
      formattedContent = `<ul class="list-disc pl-5 space-y-1">${formattedContent}</ul>`;
    }

    formattedContent = formattedContent.replace(/^\d+\. (.*$)/gm, '<li class="ml-4">$1</li>');
    if (formattedContent.match(/^\s*<li/m) && !formattedContent.includes('<ul') && !formattedContent.includes('<ol>')) {
      formattedContent = `<ol class="list-decimal pl-5 space-y-1">${formattedContent}</ol>`;
    }

    return formattedContent.replace(/\n/g, '<br />');
  };

  if (message.content === "" && !isUser) return null;

  return (
    <div className={`flex flex-col gap-2 ${isUser ? 'items-end' : 'items-start'}`}>
      <div className={`flex items-start gap-4 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
        <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${isUser ? 'bg-blue-600' : 'bg-gray-200'}`}>
          {isUser ? <UserIcon /> : <BotIcon />}
        </div>
        <div
          className={`max-w-xl px-4 py-3 rounded-lg shadow-md ${
            isUser
              ? 'bg-blue-600 text-white rounded-br-none'
              : 'bg-white/70 backdrop-blur-sm text-gray-900 rounded-bl-none'
          }`}
        >
          <div className="prose prose-sm max-w-none text-gray-800" dangerouslySetInnerHTML={{ __html: formatContent(displayContent) || "..." }}></div>
        </div>
      </div>

      {!isUser && (message.suggestions || message.kannadaContent) && (
        <div className="pl-12 pt-2 flex flex-wrap items-center gap-2">
          {message.kannadaContent && (
             <button
                onClick={() => onToggleTranslation(index)}
                disabled={message.isTranslating}
                className="flex items-center gap-1.5 px-3 py-1 bg-white/50 backdrop-blur-sm border border-gray-300 rounded-full text-sm text-red-800 hover:bg-white/80 hover:border-red-500 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-red-400 disabled:opacity-50 disabled:cursor-wait"
             >
                 <TranslateIcon />
                 {message.showKannada ? 'Show English' : 'Translate to Kannada'}
             </button>
          )}
          {message.suggestions && message.suggestions.length > 0 && message.suggestions.map((suggestion, sIndex) => (
              <button
                  key={sIndex}
                  onClick={() => onSuggestionClick(suggestion, index)}
                  className="px-3 py-1 bg-white/50 backdrop-blur-sm border border-gray-300 rounded-full text-sm text-blue-700 hover:bg-white/80 hover:border-blue-500 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-400"
              >
                  {suggestion}
              </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default ChatMessage;