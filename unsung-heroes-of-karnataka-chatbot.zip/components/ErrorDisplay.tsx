import React from 'react';

interface ErrorDisplayProps {
    message: string;
}

const ErrorDisplay: React.FC<ErrorDisplayProps> = ({ message }) => {
    return (
        <div className="flex items-start gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-red-600 flex items-center justify-center text-white font-bold">
                !
            </div>
            <div className="max-w-xl px-4 py-3 rounded-lg shadow-md bg-red-100 border border-red-300 text-red-900 rounded-bl-none">
                <p className="font-semibold">Error</p>
                <p className="text-sm">{message}</p>
            </div>
        </div>
    );
};

export default ErrorDisplay;