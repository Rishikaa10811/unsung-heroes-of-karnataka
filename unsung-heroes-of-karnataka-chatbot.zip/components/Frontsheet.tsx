import React from 'react';
import EnterIcon from './icons/EnterIcon';

interface FrontsheetProps {
  onEnter: () => void;
}

const Frontsheet: React.FC<FrontsheetProps> = ({ onEnter }) => {
  return (
    <div className="flex flex-col items-center justify-center h-screen text-white p-8 text-center animate-fade-in">
      <div className="bg-black/20 backdrop-blur-md p-8 md:p-12 rounded-2xl shadow-2xl max-w-3xl">
        <h1 className="text-4xl md:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-yellow-100 mb-4">
          Discover Karnataka's Unsung Heroes
        </h1>
        <p className="text-lg md:text-xl text-yellow-100/90 mb-8">
          Journey through history and uncover the stories of the brave, the brilliant, and the bold figures who shaped Karnataka, away from the spotlight.
        </p>
        <button
          onClick={onEnter}
          className="group inline-flex items-center justify-center px-8 py-4 bg-white text-red-600 font-bold rounded-full text-lg shadow-lg transform hover:scale-105 transition-transform duration-300 ease-in-out focus:outline-none focus:ring-4 focus:ring-yellow-300 focus:ring-opacity-50"
          aria-label="Begin Exploration and enter the chatbot"
        >
          Begin Exploration
          <span className="ml-3 transform group-hover:translate-x-2 transition-transform duration-300">
            <EnterIcon />
          </span>
        </button>
      </div>
    </div>
  );
};

export default Frontsheet;
