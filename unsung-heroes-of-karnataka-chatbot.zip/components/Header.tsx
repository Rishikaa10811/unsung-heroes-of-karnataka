
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-white/30 backdrop-blur-sm border-b border-white/50 shadow-md sticky top-0 z-10">
      <div className="max-w-4xl mx-auto px-4 md:px-6 py-3 flex justify-between items-center">
        <div>
            <h1 className="text-xl md:text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-red-500">
            Unsung Heroes of Karnataka
            </h1>
            <p className="text-sm text-red-900 font-medium">An AI-Powered Exploration</p>
        </div>
      </div>
    </header>
  );
};

export default Header;