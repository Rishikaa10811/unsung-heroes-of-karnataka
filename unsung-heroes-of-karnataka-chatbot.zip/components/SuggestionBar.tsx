import React from 'react';

interface SuggestionBarProps {
  onSuggestionClick: (suggestion: string) => void;
  isLoading: boolean;
}

const suggestions = [
  "Tell me about a freedom fighter",
  "Who was a queen from Karnataka?",
  "Tell me about a social reformer",
  "Suggest a random hero",
];

const SuggestionBar: React.FC<SuggestionBarProps> = ({ onSuggestionClick, isLoading }) => {
  if (isLoading) {
    return null;
  }

  return (
    <div className="mb-4">
        <p className="text-sm font-medium text-red-900/80 mb-2 px-1">Try asking:</p>
        <div className="flex overflow-x-auto pb-2 -mx-4 px-4 gap-2">
            {suggestions.map((text, index) => (
                <button
                    key={index}
                    onClick={() => onSuggestionClick(text)}
                    className="flex-shrink-0 px-3 py-1 bg-white/50 backdrop-blur-sm border border-gray-300 rounded-full text-sm text-blue-700 hover:bg-white/80 hover:border-blue-500 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-400"
                >
                    {text}
                </button>
            ))}
        </div>
    </div>
  );
};

export default SuggestionBar;
