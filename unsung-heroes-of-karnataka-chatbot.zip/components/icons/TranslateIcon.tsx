import React from 'react';

const TranslateIcon: React.FC = () => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    className="h-4 w-4" 
    viewBox="0 0 20 20" 
    fill="currentColor"
  >
    <path d="M7 2a1 1 0 011 1v1h3a1 1 0 110 2H9.382a2.96 2.96 0 01.275.562l.71 1.42A4.969 4.969 0 0114 9.5V11a.5.5 0 00.5.5h2a.5.5 0 00.5-.5V8.21a1 1 0 00-.553-.894l-4-2A1 1 0 0012 4.43V2a1 1 0 01-1-1H7zM3 4a1 1 0 011-1h1a1 1 0 011 1v11a1 1 0 01-1 1H4a1 1 0 01-1-1V4z" />
    <path fillRule="evenodd" d="M15.707 12.293a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 111.414-1.414L11 14.586V9.5a1 1 0 112 0v5.086l2.293-2.293a1 1 0 011.414 0z" clipRule="evenodd" />
  </svg>
);

export default TranslateIcon;