import { GoogleGenAI, Chat, Type } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const chat: Chat = ai.chats.create({
  model: 'gemini-2.5-flash',
  config: {
    systemInstruction: `You are a knowledgeable and respectful chatbot specializing in the unsung heroes of Karnataka. 
    Your purpose is to educate users about figures from Karnataka's history who are not widely celebrated but have made significant contributions.
    - Provide concise, informative, and engaging answers.
    - If a user asks about a topic outside this scope (e.g., general knowledge, current events, other regions), gently and politely guide them back to the subject of Karnataka's unsung heroes.
    - Do not engage in conversations unrelated to your primary purpose.
    - Format your responses in Markdown for better readability. Use headings, lists, and bold text where appropriate.`,
  },
});

export async function sendMessageStream(message: string) {
    try {
        const result = await chat.sendMessageStream({ message });
        return result;
    } catch(error) {
        console.error('Error in sendMessageStream:', error);
        throw new Error('Failed to get response from Gemini API.');
    }
}

export async function translateText(text: string, targetLanguage: 'Kannada' | 'English'): Promise<string> {
    try {
        const prompt = `Translate the following text to ${targetLanguage}. Provide only the translated text, without any additional formatting, commentary, or quotation marks.

        Text to translate:
        "${text}"`;
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        
        return response.text.trim();
    } catch (error) {
        console.error('Error in translateText:', error);
        throw new Error(`Failed to translate text to ${targetLanguage}.`);
    }
}

export async function getRelatedHeroes(topic: string): Promise<string[]> {
    try {
        const prompt = `Based on the topic "${topic}", suggest up to 3 related unsung heroes from Karnataka. They could be from the same time period, same region, or have similar contributions.`;
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        heroes: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.STRING,
                                description: "Name of a related unsung hero from Karnataka"
                            }
                        }
                    },
                    required: ['heroes']
                }
            }
        });
        
        const jsonText = response.text.trim();
        const result = JSON.parse(jsonText);

        if (result && Array.isArray(result.heroes)) {
            return result.heroes;
        }

        return [];

    } catch (error) {
        console.error('Error in getRelatedHeroes:', error);
        // Return an empty array so the UI doesn't break on error
        return [];
    }
}