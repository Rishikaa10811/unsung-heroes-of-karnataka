export enum Role {
  USER = 'user',
  MODEL = 'model',
}

export interface Message {
  role: Role;
  content: string; // Default/English content
  kannadaContent?: string;
  isTranslating?: boolean;
  suggestions?: string[];
  showKannada?: boolean;
}